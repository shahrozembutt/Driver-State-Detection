package com.example.capstone;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class BuzzerButton extends AppCompatActivity {

    private Button StopButton;
    private TextView AlertText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buzzer_button);

        final MediaPlayer alarmSoundMP = MediaPlayer.create(this, R.raw.alarm_sound);
        Button StopButton = (Button) this.findViewById(R.id.StopButton);
        StopButton = findViewById(R.id.StopButton);
        AlertText = findViewById(R.id.AlertText);

        StopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(BuzzerButton.this);

                builder.setCancelable(true);
                builder.setTitle("The System Detected User Was Drowsy");
                builder.setMessage("Please pull over and respond accordingly");

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        AlertText.setVisibility(View.VISIBLE);
                    }
                });
                builder.show();
                alarmSoundMP.release();
            }
        });
    }
}