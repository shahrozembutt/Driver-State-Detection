package com.example.capstone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText username, password;
    Button signInButton1;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final MediaPlayer alarmSoundMP = MediaPlayer.create(this, R.raw.alarm_sound);
        Button signInButton1 = (Button) this.findViewById(R.id.signInButton1);


        username= findViewById(R.id.username1);
        password= findViewById(R.id.password1);
        signInButton1 =findViewById(R.id.signInButton1);
        DB = new DBHelper(this);

        signInButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user= username.getText().toString();
                String pass=password.getText().toString();

                if(TextUtils.isEmpty(user) || TextUtils.isEmpty(pass))
                    Toast.makeText(LoginActivity.this, "All Fields Required", Toast.LENGTH_SHORT).show();
                else
                {
                    Boolean checkusernamepassword=DB.checkusernamepassword(user, pass);
                    if(checkusernamepassword==true)
                    {
                        Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        alarmSoundMP.start();
                        Intent intent=new Intent(getApplicationContext(), BuzzerButton.class);
                        startActivity(intent);

                    }
                    else
                    {
                        Toast.makeText(LoginActivity.this, "", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }
}